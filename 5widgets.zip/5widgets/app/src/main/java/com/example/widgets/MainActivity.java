package com.example.widgets;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private CheckBox appleCheckBox;
    private CheckBox orangeCheckBox;
    private CheckBox grapesCheckBox;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.user);
        passwordEditText = findViewById(R.id.pass);
        appleCheckBox = findViewById(R.id.itemCheckBox1);
        orangeCheckBox = findViewById(R.id.itemCheckBox2);
        grapesCheckBox = findViewById(R.id.itemCheckBox3);
        submitButton = findViewById(R.id.button);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                String selectedFruit = getSelectedFruit();
                String message = "Username: " + username + "\nPassword: " + password + "\nSelected Fruit: " + selectedFruit;
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });

        setCheckboxListeners();
    }

    private void setCheckboxListeners() {
        appleCheckBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uncheckOtherCheckboxes(appleCheckBox);
            }
        });

        orangeCheckBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uncheckOtherCheckboxes(orangeCheckBox);
            }
        });

        grapesCheckBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uncheckOtherCheckboxes(grapesCheckBox);
            }
        });
    }

    private void uncheckOtherCheckboxes(CheckBox checkedBox) {
        if (checkedBox == appleCheckBox) {
            orangeCheckBox.setChecked(false);
            grapesCheckBox.setChecked(false);
        } else if (checkedBox == orangeCheckBox) {
            appleCheckBox.setChecked(false);
            grapesCheckBox.setChecked(false);
        } else if (checkedBox == grapesCheckBox) {
            appleCheckBox.setChecked(false);
            orangeCheckBox.setChecked(false);
        }
    }

    private String getSelectedFruit() {
        if (appleCheckBox.isChecked()) {
            return "Apple";
        } else if (orangeCheckBox.isChecked()) {
            return "Orange";
        } else if (grapesCheckBox.isChecked()) {
            return "Grapes";
        } else {
            return "None";
        }
    }
}
